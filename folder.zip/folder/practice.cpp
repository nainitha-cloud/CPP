#include <iostream>
using namespace std;
class sample
{
	public:
		int *ptr;
		sample(int val)
		{
			ptr = new int;
			*ptr = val;
			cout<<"parametrized const";
		}
		sample(sample &s)
		{
			ptr = new int;
			*ptr = *(s.ptr);
			
		}
		void show()
		{
			cout<<"Value :"<<*ptr;
		}
		
};
int main()
{
	sample s1(20);
	s1.show();
	sample s2(s1);
	s2.show();
	
}
