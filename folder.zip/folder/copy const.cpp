#include <iostream>
using namespace std;

class Number {
    int *ptr;
public:
    Number(int val) {
        ptr = new int;
        *ptr = val;
        cout << "Constructor called" << endl;
    }

    Number(const Number &obj) {
        ptr = new int;
        *ptr = *(obj.ptr);
        cout << "Copy Constructor called" << endl;
    }

    void show() {
        cout << "Value: " << *ptr << endl;
    }

    ~Number() {
        delete ptr;
        cout << "Destructor called" << endl;
    }
};

int main() {
    Number n1(10);      // Constructor
    Number n2(n1);      // Copy Constructor (same as n2 = n1)
    n2.show();

    return 0;
}

