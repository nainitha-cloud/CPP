#include <iostream>
using namespace std;
class Rectangle
{
	private:
		int length,breadth;
		public:
			Rectangle()
			{
				cout<<"enter length and breadth values of rectangle:";
				cin>>length>>breadth;
			}
			Rectangle( Rectangle &r)
			{
			length = r.length;
			breadth = r.breadth;
			}
			void area()
			{
				cout<<"Area of rectangle:"<<length*breadth<<endl;
			}
			
			};
int main()
{
  Rectangle r1;
  r1.area();
  cout<<"Using copy constructor:"<<endl;
  Rectangle r2(r1);
  r2.area();
  return 0;
  	
}
