#include <iostream>
using namespace std;
class Rectangle
{
	private:
		int length,breadth;
		public:
			void getdata(int l,int b)
			{
				length = l;
				breadth = b;
			}
			friend void area(Rectangle &r);
};
void area(Rectangle &r)
{
	int area;
	area = r.length*r.breadth;
	cout<<"Area of rectangle:"<<area;
}
int main()
{
	Rectangle r1;
	r1.getdata(10,20);
	area(r1);
}
