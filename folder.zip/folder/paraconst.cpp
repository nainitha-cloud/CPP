#include <iostream>
using namespace std;
class Rectangle
{
	private:
		int length,breadth;
		public:
			Rectangle(int l,int b)
			{
			 length = l;
			 breadth = b;
			}
			
			void area()
			{
				cout<<"Area of rectangle:"<<length*breadth<<endl;
			}
			
			};
int main()
{ int length,breadth;
	 cout<<"enter length and breadth:";
	cin>>length>>breadth;
  Rectangle r1(length,breadth);
 
  r1.area();
  return 0;
  	
}
