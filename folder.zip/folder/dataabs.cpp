#include <iostream>
using namespace std;
class Square
{
	private:
		int side;
	public:
		void get()
		{
			cout<<"enter side of square:";
			cin>>side;
		}
		void print_area()
		{
			cout<<"Area of the sqaure: "<<side*side;
		}
};
int main()
{
	Square s;
	s.get();
	s.print_area();
	return 0;
}
