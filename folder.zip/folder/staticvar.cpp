#include <iostream>
using namespace std;
class Demo
{
	public:
		int static x;
		
};
int Demo::x = 30;
int main()
{
	cout<<"Static variable value:"<<Demo::x;
	return 0;
}
