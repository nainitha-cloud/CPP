#include <iostream>
using namespace std;
class Box
{
	private:
		int length;
		public:
			int getlength()
			{
				cout<<"Enter length of box:";
				cin>>length;
			}
			friend int printlength(Box b);
};
int printlength(Box b)
{
	b.length+=10;
	return b.length;
}
int main()
{
	Box b;
	b.getlength();
	cout<<"length of the box after adding 10:"<<printlength(b);
	return 0;
	
}
