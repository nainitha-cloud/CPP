#include <iostream>
using namespace std;

class Number {
    int *ptr;   // pointer for dynamic integer
public:
    // Constructor
    Number(int val) {
        ptr = new int;
        *ptr = val;
        cout << "Constructor called" << endl;
    }


    // Function to add two Numbers
    Number add(const Number &obj) {
        int sum = *ptr + *(obj.ptr);
        return Number(sum); // returns a new object
    }

    // Display function
    void show() {
        cout << "Value: " << *ptr << endl;
    }

    // Destructor
    ~Number() {
        delete ptr;
        cout << "Destructor called" << endl;
    }
};

int main() {
    Number n1(10);        // Constructor
    Number n2(20);        // Constructor

    Number n3 = n1.add(n2); // Perform addition
    cout << "Result Object: ";
    n3.show();             // Display result

    return 0;
}

