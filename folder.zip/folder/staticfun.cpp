#include <iostream>
using namespace std;
class Demo
{
	private:
		static int x,y;
	public:
		static void sum()
		
		{
			cout<<"Enter x and y values:";
			cin>>x>>y;
			cout<<"sum of x and y is:"<<x+y;
		}
};
int Demo::x;
int Demo::y;
int main()
{
	Demo::sum();
	
}
